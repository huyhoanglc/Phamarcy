/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

import java.time.LocalDateTime;

/**
 *
 * @author Admin
 */
public class Data {

    public static String[] status = {"Available ", "Unavailable"};
    public static String dl_MedicineID;
    public static String dl_MedicineName;
    public static String dl_API;
    public static Integer dl_Costprice;
    public static Integer dl_Sellingprice;
    public static Integer dl_Quantity;
    public static Integer dl_Subunitsperunit;
    public static Integer dl_Itemspersubunit;
    public static String dl_Unit;
    public static String dl_Subunit;
    public static String dl_Item;
    public static String[] role = {"Manager ", "Staff"};
    public static String al_fullname;
    public static String al_phone;
    public static String al_password;
    public static String al_address;
    public static String al_role;
    public static int al_ID;
    public static String al_email;
    public static LocalDateTime al_datecreated;
    
}
